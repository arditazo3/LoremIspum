
TRUNCATE TABLE categories;

TRUNCATE TABLE domains;

TRUNCATE TABLE events;

TRUNCATE TABLE images;

TRUNCATE TABLE migrations;

TRUNCATE TABLE options;

TRUNCATE TABLE password_resets;

TRUNCATE TABLE patients;

TRUNCATE TABLE roles;

TRUNCATE TABLE users;

