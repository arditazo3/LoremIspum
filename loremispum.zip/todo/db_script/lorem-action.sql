
select * from options;

select * from patients;

select * from events;

select * from users;

select * from users where id = 51;

select * from roles;

select * from images;

select * from domains where des_dom = 'typeStatus';

select * from categories;

select * from jobs;

select * from job_details;

select * from teeths_prizes;

