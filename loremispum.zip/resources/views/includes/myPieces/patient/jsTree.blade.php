<div class="ibox-content">

    <div id="jstree1">

        <ul>
            @foreach($listCures as $cure)
                {!! $cure !!}
            @endforeach
        </ul>

    </div>

</div>