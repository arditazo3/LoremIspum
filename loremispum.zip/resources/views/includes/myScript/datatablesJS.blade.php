<script src="{{ URL::asset('js/extra/jquery.dataTables.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('js/extra/dataTables.bootstrap.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('js/extra/dataTables.responsive.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('js/extra/dataTables.tableTools.min.js') }}" type="text/javascript"></script>
