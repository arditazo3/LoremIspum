<script src="{{ URL::asset('js/extra/jquery.validate.min.js') }}" type="text/javascript"></script>
