<script src="{{ URL::asset('js/extra/toastr.min.js') }}" type="text/javascript"></script>
