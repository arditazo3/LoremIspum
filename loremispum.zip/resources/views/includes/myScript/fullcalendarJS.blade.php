<script src="{{ URL::asset('js/extra/moment.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('js/extra/daterangepicker.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('js/extra/fullcalendar.min.js') }}" type="text/javascript"></script>
