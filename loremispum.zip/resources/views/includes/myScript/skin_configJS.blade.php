<script src="{{ URL::asset('js/extra/skin-configJS.js') }}" type="text/javascript"></script>

