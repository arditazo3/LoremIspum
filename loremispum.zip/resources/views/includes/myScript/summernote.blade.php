<script src="{{ URL::asset('js/extra/summernote.min.js') }}" type="text/javascript"></script>

