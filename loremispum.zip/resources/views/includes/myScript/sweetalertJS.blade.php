<script src="{{ URL::asset('js/extra/sweetalert.min.js') }}" type="text/javascript"></script>
