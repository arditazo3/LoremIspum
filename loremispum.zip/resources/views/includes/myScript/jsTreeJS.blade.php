<script src="{{ URL::asset('js/extra/jsTree.js') }}" type="text/javascript"></script>
