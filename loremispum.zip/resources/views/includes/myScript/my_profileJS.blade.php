<script src="{{ URL::asset('js/extra/my_profile.js') }}" type="text/javascript"></script>
