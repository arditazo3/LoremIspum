<link href="{{ URL::asset('css/extra/summernote.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('css/extra/summernote-bs3.css') }}" rel="stylesheet" type="text/css"/>
