<link href="{{ URL::asset('css/extra/daterangepicker.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('css/extra/fullcalendar.min.css') }}" rel="stylesheet" type="text/css"/>

{{-- CHANGE THE STYLE IF IS ENABLE --}}
{{--<link href="{{ URL::asset('css/extra/fullcalendar.print.css') }}" rel="stylesheet" type="text/css"/>--}}
