<link href="{{ URL::asset('css/extra/dataTables.bootstrap.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('css/extra/dataTables.responsive.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('css/extra/dataTables.tableTools.min.css') }}" rel="stylesheet" type="text/css"/>
<link href="{{ URL::asset('css/extra/jquery.dataTables.min.css') }}" rel="stylesheet" type="text/css"/>
