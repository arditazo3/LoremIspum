<link href="<?php echo e(URL::asset('css/extra/toastr.min.css')); ?>" rel="stylesheet" type="text/css"/>
