<?php $__env->startSection('myCSS'); ?>
    <?php echo $__env->make('includes.myCSS.toastr', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!--PUT THE NICE FORM HERE-->
    <?php echo $__env->make('webapp-layouts.my_account.form_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('myScript'); ?>

    <?php echo $__env->make('includes.myScript.toastr', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.myScript.jquery_validate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('includes.myScript.my_profileJS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',
    ['title'=> 'Account Panel', 'subTitle'=>'My Profile',
     'activeOpen'=> 'MyAccountPanel', 'activeOpenSub'=> 'MyProfile',
     'website'=>$website], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>