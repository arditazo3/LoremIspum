<div class="modal inmodal fade" id="chartsModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-larger">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span
                            aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title pull-left">Chart panel</h4>
            </div>
            <div class="modal-body">

                <div class="row">

                    <div class="col-sm-9 b-r">

                    </div>

                    <div class="col-sm-3 b-r">

                        <div style="position: relative; width: 100%; height: 431px;">
                            <img src="<?php echo e($website . 'images/teeths_chart/the_source.jpg'); ?>" alt="" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">

                            <img id="dent_teeth_32" src="<?php echo e($website . 'images/teeths/32.png'); ?>" alt=""
                                 style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
                            <img id="dent_teeth_31" src="<?php echo e($website . 'images/teeths/31.png'); ?>" alt=""
                                 style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">

                        </div>

                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>