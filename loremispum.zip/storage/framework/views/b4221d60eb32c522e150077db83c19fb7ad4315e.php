<link href="<?php echo e(URL::asset('css/extra/daterangepicker.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(URL::asset('css/extra/fullcalendar.min.css')); ?>" rel="stylesheet" type="text/css"/>

<?php /* CHANGE THE STYLE IF IS ENABLE */ ?>
<?php /*<link href="<?php echo e(URL::asset('css/extra/fullcalendar.print.css')); ?>" rel="stylesheet" type="text/css"/>*/ ?>
