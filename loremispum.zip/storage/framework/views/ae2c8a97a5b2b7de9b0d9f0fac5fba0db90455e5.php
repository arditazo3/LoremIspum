<?php $__env->startSection('content'); ?>

    <div>
        <div>

            <h1 class="logo-name">WA</h1>

        </div>
        <h3>Register to WebApp.al</h3>
        <p>Create account to see it in action.</p>
        <?php echo Form::open(['method'=>'POST', 'action'=>'Auth\AuthController@register', 'class'=>'m-t', 'role'=>'form']); ?>



        <div class="form-group">
            <div class="input-group m-b"><span class="input-group-addon"><i
                            class="fa fa-github-alt"></i></span>
                <?php echo Form::text('first_name', null, ['class'=>'form-control', 'placeholder'=>'First Name']); ?>

            </div>
        </div>
        <div class="form-group">
            <div class="input-group m-b"><span class="input-group-addon"><i
                            class="fa fa-github-alt"></i></span>
                <?php echo Form::text('last_name', null, ['class'=>'form-control', 'placeholder'=>'Last Name']); ?>

            </div>
        </div>
        <div class="form-group">
            <div class="input-group m-b"><span class="input-group-addon"><i
                            class="fa fa-envelope"></i></span>
                <input type="email" name="email" class="form-control" placeholder="Email">
            </div>
        </div>
        <div class="form-group">
            <div class="input-group m-b"><span class="input-group-addon"><i
                            class="fa fa-lock"></i></span>
                <?php echo Form::password('password', ['class'=>'form-control placeholder-no-fix', 'placeholder'=>'Password']); ?>

            </div>
        </div>
        <div class="form-group">
            <div class="input-group m-b"><span class="input-group-addon"><i
                            class="fa fa-lock"></i></span>
                <?php echo Form::password('password_confirmation', ['class'=>'form-control placeholder-no-fix', 'placeholder'=>'Confirm Password']); ?>

            </div>
        </div>

        <div class="form-group">
            <div class="checkbox i-checks"><label> <input type="checkbox"><i></i> Agree the terms and policy </label>
            </div>
        </div>

        <?php echo $__env->make('includes.form-error-specify', ['field'=>'name', 'typeAlert'=>'danger'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('includes.form-error-specify', ['field'=>'email', 'typeAlert'=>'danger'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('includes.form-error-specify', ['field'=>'password', 'typeAlert'=>'danger'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo Form::submit('Register', ['class'=>'btn btn-primary block full-width m-b']); ?>


        <p class="text-muted text-center">
            Already have an account?
        </p>
        <a class="btn btn-primary btn-sm btn-block" href="<?php echo e(url('login')); ?>">Login</a>
        <?php echo Form::close(); ?>

        <p class="m-t"><?php echo e(\Carbon\Carbon::now()->year); ?> © WebApp.al</p>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-sign', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>