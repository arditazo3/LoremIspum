<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('myScript'); ?>

    <script>

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',
    ['title'=> 'Account Panel', 'subTitle'=>'Contacts',
     'activeOpen'=> 'MyAccountPanel', 'activeOpenSub'=> 'Mailbox',
     'website'=>\App\Option::findOrFail(1)->value], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>