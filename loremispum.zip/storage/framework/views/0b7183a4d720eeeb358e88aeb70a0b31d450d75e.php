<?php $__env->startSection('content'); ?>

    <div class="row">
        <?php foreach($users as $user): ?>

            <div class="col-lg-4">
                <div class="contact-box">
                    <?php /* WE PUT THE OBJECT HERE AND RETRIEVE IT AFTER CLICK */ ?>
                    <a href="<?php echo e($user); ?>">
                        <div class="col-sm-4">
                            <div class="text-center">
                                <img alt="image" class="img-circle m-t-xs img-responsive"
                                     src="<?php echo e($user->image ? ($website . $user->image->path) : ($website . 'img/user-no_photo.png')); ?>">
                                <div class="m-t-xs font-bold"><?php echo e($user->role ? $user->role->status : 'No role'); ?></div>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <h3><strong>
                                    <?php if(Auth::user()->id == $user->id): ?>
                                        <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> (My profile)
                                    <?php elseif(Auth::user()->id != $user->id): ?>
                                        <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                                    <?php endif; ?>
                                </strong></h3>
                            <p>
                                <i class="fa fa-map-marker"></i> <?php echo e(trim($user->address) == '' ? 'No address' : $user->address); ?>

                            </p>
                            <p><i class="fa fa-phone"></i> <?php echo e($user->phone); ?> </p>
                        </div>
                        <div class="clearfix"></div>
                    </a>
                </div>
            </div>

        <?php endforeach; ?>
    </div>


    <div class="modal inmodal fade" id="modalUserProfile" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span
                                aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title pull-left">Update profile</h4>
                </div>

                <!--PUT THE NICE FORM HERE-->
                <?php echo $__env->make('webapp-layouts.my_account.form_user', ['user'=>$user], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>
        </div>
    </div>
    <?php /*END EDIT MODAL*/ ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('myScript'); ?>
    <?php echo $__env->make('includes.myScript.toastr', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('includes.myScript.jquery_validate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('includes.myScript.my_profileJS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script>

        var getPathProfilePicAjax = '<?php echo e(route('api/getPathProfilePicAjax')); ?>';
        var token = '<?php echo e(\Illuminate\Support\Facades\Session::token()); ?>';

        $(document).ready(function () {

            $('.row').on('click', 'a', function (e) {
                e.preventDefault();

                console.log($(this).attr('href'));

                var user = JSON.parse($(this).attr('href'));
                setProfilePicture(user["image_id"], user);

            });

        });

        function setProfilePicture(idImange, user) {

            var getProfilePicPath = '';

            $.ajax({
                method: 'POST',
                url: getPathProfilePicAjax,
                data: {
                    image_id: idImange,
                    _token: token
                }
            })
            .done(function (msg) {
                console.log("Test");
                console.log(JSON.stringify(msg));
                getProfilePicPath = msg;

                var imagePath = "<?php echo e($website); ?>" + getProfilePicPath['image_id'];

                $('#id_user').val(user["id"]);
                $('#first_name').val(user["first_name"]);
                $('#last_name').val(user["last_name"]);
                $('#email').val(user["email"]);
                $('#phone').val(user["phone"]);
                $('#address').val(user["address"]);
                $('#defaultProfilePicture img').attr("src", imagePath);

                $('#modalUserProfile').modal({backdrop: 'static', keyboard: false});
            });

        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',
    ['title'=> 'Account Panel', 'subTitle'=>'Contacts',
     'activeOpen'=> 'MyAccountPanel', 'activeOpenSub'=> 'Contacts',
     'website'=>\App\Option::findOrFail(1)->value], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>