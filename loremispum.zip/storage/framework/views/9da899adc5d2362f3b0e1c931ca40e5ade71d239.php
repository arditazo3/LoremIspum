<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <h1>CalendarEvents</h1>
    </div>


    <div class="row">
        <div class="col-md-12">

            <?php echo $calendar_events->calendar(); ?>

            <?php echo $calendar_events->script(); ?>


            <table class="table table-striped">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>TITLE</th>
                    <th>START</th>
                    <th>END</th>
                    <th>IS_ALL_DAY</th>
                    <th>BACKGROUND_COLOR</th>
                    <th class="text-right">OPTIONS</th>
                </tr>
                </thead>

                <tbody>

                <?php foreach($calendar_events as $calendar_event): ?>
                    <tr>
                        <td><?php echo e($calendar_event->id); ?></td>
                        <td><?php echo e($calendar_event->title); ?></td>
                        <td><?php echo e($calendar_event->start); ?></td>
                        <td><?php echo e($calendar_event->end); ?></td>
                        <td><?php echo e($calendar_event->is_all_day); ?></td>
                        <td><?php echo e($calendar_event->background_color); ?></td>

                        <td class="text-right">
                            <a class="btn btn-primary" href="<?php echo e(route('calendar_events.show', $calendar_event->id)); ?>">View</a>
                            <a class="btn btn-warning " href="<?php echo e(route('calendar_events.edit', $calendar_event->id)); ?>">Edit</a>
                            <form action="<?php echo e(route('calendar_events.destroy', $calendar_event->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><input type="hidden" name="_method" value="DELETE"><input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <button class="btn btn-danger" type="submit">Delete</button></form>
                        </td>
                    </tr>

                <?php endforeach; ?>

                </tbody>
            </table>

            <a class="btn btn-success" href="<?php echo e(route('calendar_events.create')); ?>">Create</a>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',
    ['title'=> 'Calendar Panel', 'subTitle'=>'New Event',
     'activeOpen'=> 'CalendarPanel', 'activeOpenSub'=> 'NewEvent',
     'website'=>\App\Option::findOrFail(1)->value], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>