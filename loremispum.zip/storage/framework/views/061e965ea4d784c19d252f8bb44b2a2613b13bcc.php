<script src="<?php echo e(URL::asset('js/extra/summernote.min.js')); ?>" type="text/javascript"></script>

