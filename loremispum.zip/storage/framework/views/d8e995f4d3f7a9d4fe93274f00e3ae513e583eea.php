<script src="<?php echo e(URL::asset('js/extra/my_profile.js')); ?>" type="text/javascript"></script>
