<script src="<?php echo e(URL::asset('js/extra/skin-configJS.js')); ?>" type="text/javascript"></script>

