<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <h1>CalendarEvents / Edit </h1>
    </div>


    <div class="row">
        <div class="col-md-12">

            <form action="<?php echo e(route('calendar_events.update', $calendar_event->id)); ?>" method="POST">
                <input type="hidden" name="_method" value="PUT">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                <div class="form-group">
                    <label for="nome">ID</label>
                    <p class="form-control-static"><?php echo e($calendar_event->id); ?></p>
                </div>
                <div class="form-group">
                    <label for="title">TITLE</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($calendar_event->title); ?>"/>
                </div>
                <div class="form-group">
                    <label for="start">START</label>
                    <input type="text" name="start" class="form-control" value="<?php echo e($calendar_event->start); ?>"/>
                </div>
                <div class="form-group">
                    <label for="end">END</label>
                    <input type="text" name="end" class="form-control" value="<?php echo e($calendar_event->end); ?>"/>
                </div>
                <div class="form-group">
                    <label for="is_all_day">IS_ALL_DAY</label>
                    <input type="text" name="is_all_day" class="form-control" value="<?php echo e($calendar_event->is_all_day); ?>"/>
                </div>
                <div class="form-group">
                    <label for="background_color">BACKGROUND_COLOR</label>
                    <input type="text" name="background_color" class="form-control" value="<?php echo e($calendar_event->background_color); ?>"/>
                </div>



                <a class="btn btn-default" href="<?php echo e(route('calendar_events.index')); ?>">Back</a>
                <button class="btn btn-primary" type="submit" >Save</button>
            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',
    ['title'=> 'Calendar Panel', 'subTitle'=>'New Event',
     'activeOpen'=> 'CalendarPanel', 'activeOpenSub'=> 'NewEvent',
     'website'=>\App\Option::findOrFail(1)->value], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>