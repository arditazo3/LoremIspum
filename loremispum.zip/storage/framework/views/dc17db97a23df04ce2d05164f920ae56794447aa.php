<script src="<?php echo e(URL::asset('js/extra/jsTree.js')); ?>" type="text/javascript"></script>
