<?php $__env->startSection('content'); ?>

    <?php if(\Illuminate\Support\Facades\Session::has('deleted_patient')): ?>
        <?php echo $__env->make('includes.notification-alert', ['alert_type'=> 'danger', 'msg'=> session('deleted_patient')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(\Illuminate\Support\Facades\Session::has('updated_patient')): ?>
        <?php echo $__env->make('includes.notification-alert', ['alert_type'=> 'warning', 'msg'=> session('updated_patient')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(\Illuminate\Support\Facades\Session::has('created_patient')): ?>
        <?php echo $__env->make('includes.notification-alert', ['alert_type'=> 'success', 'msg'=> session('created_patient')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>

    <?php if(\Illuminate\Support\Facades\Session::has('deleted_user')): ?>
        <?php echo $__env->make('includes.notification-alert', ['alert_type'=> 'danger', 'msg'=> session('deleted_user')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(\Illuminate\Support\Facades\Session::has('updated_user')): ?>
        <?php echo $__env->make('includes.notification-alert', ['alert_type'=> 'warning', 'msg'=> session('updated_user')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(\Illuminate\Support\Facades\Session::has('created_user')): ?>
        <?php echo $__env->make('includes.notification-alert', ['alert_type'=> 'success', 'msg'=> session('created_user')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('myScript'); ?>

    <?php echo $__env->make('includes.myScript.skin_configJS', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',
    ['title'=> 'Dashboard Panel', 'subTitle'=>'Dashboard',
     'activeOpen'=> 'DashboardPanel', 'activeOpenSub'=> 'Dashboard',
     'website'=>\App\Option::findOrFail(1)->value], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>