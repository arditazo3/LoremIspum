<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-6">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Edit event</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                        <a class="close-link">
                            <i class="fa fa-times"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <div class="row">
                        <?php echo Form::model($event, ['method'=>'PATCH', 'action'=>['CalendarController@update',  $event->id] ]); ?>


                        <div class="form-group ">
                            <?php echo Form::label('name', 'Name', ['class'=>'control-label']); ?>

                            <?php echo Form::text('name', null, ['class'=>'form-control', 'placeholder'=>'First name']); ?>

                            <?php echo $__env->make('includes.form-error-specify', ['field'=>'name', 'typeAlert'=>'danger'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>

                        <div class="form-group ">
                            <?php echo Form::label('title', 'Title', ['class'=>'control-label']); ?>

                            <?php echo Form::text('title', null, ['class'=>'form-control', 'placeholder'=>'First name']); ?>

                            <?php echo $__env->make('includes.form-error-specify', ['field'=>'title', 'typeAlert'=>'danger'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>


                        <div class="form-group ">
                            <div class="input-group">
                                <input type="text" class="form-control" name="time"
                                       value="<?php echo e($event->start_time . ' - ' . $event->end_time); ?>"
                                       placeholder="Select your time">
                            <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                            </span>
                            </div>
                        </div>


                        <?php echo Form::submit('Update event', ['class'=>'btn btn-primary btn-sm']); ?>


                        <?php echo Form::close(); ?>

                        <?php /*END FORM*/ ?>

                        <div class="pull-right">
                            <?php echo Form::open(['method'=>'DELETE', 'action'=>['CalendarController@destroy', $event->id ]]); ?>


                                <?php echo Form::submit('Delete event', ['class'=>'btn btn-danger btn-sm']); ?>

                            <?php echo Form::close(); ?>

                            <?php /*END FORM*/ ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('myScript'); ?>

<script type="text/javascript">
    $(function() {
        $('input[name="time"]').daterangepicker({
            timePicker: true,
            "timePicker24Hour": true,
            "timePickerIncrement": 15,
            "autoApply": true,
            "locale": {
                "format": "DD/MM/YYYY HH:mm:ss",
                "separator": " - ",
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin',
    ['title'=> 'Calendar Panel', 'subTitle'=>'Edit event',
     'activeOpen'=> 'CalendarPanel', 'activeOpenSub'=> 'Calendar',
     'website'=>\App\Option::findOrFail(1)->value], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>