<div class="ibox-content">

    <div id="jstree1">

        <ul>
            <?php foreach($listCures as $cure): ?>
                <?php echo $cure; ?>

            <?php endforeach; ?>
        </ul>

    </div>

</div>