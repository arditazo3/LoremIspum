<?php if($errors->has($field)): ?>
    <ul class="list-group">
        <div class="alert alert-<?php echo e($typeAlert); ?>">
            <?php echo e($errors->first($field)); ?>

        </div>
    </ul>
<?php endif; ?>