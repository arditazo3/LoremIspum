<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="WebApp.al" name="description"/>
    <meta content="WebApp.al" name="author"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="icon" href="<?php echo e(URL::asset('img/logo.ico')); ?>"/>

    <title>WebApp.al</title>

    <link href="<?php echo e(URL::asset('css/libs.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(URL::asset('css/app.css')); ?>" rel="stylesheet" type="text/css"/>

    <?php /*PUT SOME CSS WITH LOVE, BELLOW*/ ?>
    <?php echo $__env->yieldContent('myCSS'); ?>

</head>

<body>

<div id="wrapper">

    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                            <span>
                                <img alt="image" class="img-circle" src="<?php echo e(Auth::user()->image ? ($website . Auth::user()->image->path) : ($website . 'img/user-no_photo.png')); ?>" width="70"/>
                            </span>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear">
                                    <span class="block m-t-xs">
                                        <strong class="font-bold">
                                            <?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?>

                                        </strong>
                                    </span> <span class="text-muted text-xs block">
                                        <?php echo e(Auth::user()->role ? Auth::user()->role->status : 'Guess'); ?>

                                        <b class="caret"></b></span>
                                </span>
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a href="profile.html">Profile</a></li>
                            <li><a href="contacts.html">Contacts</a></li>
                            <li><a href="mailbox.html">Mailbox</a></li>
                            <li class="divider"></li>
                            <li><a href="<?php echo e(url('logout')); ?>">Logout</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        WA
                    </div>
                </li>

                <li class="<?php echo e(isset($activeOpen) && $activeOpen == 'DashboardPanel' ? 'active' : ''); ?>">

                    <a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-home"></i> <span class="nav-label">Dashboard</span> <span></span></a>
                </li>

                <?php /*PATIENT ITEM*/ ?>
                <?php /*- NEW PATIENT*/ ?>
                <li class="<?php echo e(isset($activeOpen) && $activeOpen == 'PatientPanel' ? 'active' : ''); ?>">
                    <a href="index.html"><i class="fa fa-users"></i> <span class="nav-label">Patients</span> <span
                                class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">

                        <li class="<?php echo e(isset($activeOpenSub) && $activeOpenSub == 'NewPatient' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.patient.index')); ?>"><i class="fa fa-user"></i>Patient Data</a></li>

                    </ul>
                </li>

                <?php /*CALENDAR ITEM*/ ?>
                <?php /*- APPOINTMENTS*/ ?>
                <?php /*- NEW EVENT*/ ?>
                <li class="<?php echo e(isset($activeOpen) && $activeOpen == 'CalendarPanel' ? 'active' : ''); ?>">
                    <a href="index.html"><i class="fa fa-calendar"></i> <span class="nav-label">Calendar</span> <span
                                class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">

                        <li class="<?php echo e(isset($activeOpenSub) && $activeOpenSub == 'Calendar' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.calendar.index')); ?>"><i class="fa fa-calendar"></i>Appointments</a></li>

                    </ul>
                </li>


                <li class="<?php echo e(isset($activeOpen) && $activeOpen == 'MyAccountPanel' ? 'active' : ''); ?>">
                    <a href="index.html"><i class="fa fa-user-md"></i> <span class="nav-label">My Account</span> <span
                                class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">

                        <li class="<?php echo e(isset($activeOpenSub) && $activeOpenSub == 'MyProfile' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.user.profile')); ?>"><i class="fa fa-meh-o"></i>My Profile</a></li>

                        <li class="<?php echo e(isset($activeOpenSub) && $activeOpenSub == 'Contacts' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.user.contacts')); ?>"><i class="fa fa-phone"></i>Contacts</a></li>

                        <li class="<?php echo e(isset($activeOpenSub) && $activeOpenSub == 'Mailbox' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('admin.user.mailbox')); ?>"><i class="fa fa-envelope"></i>Mailbox</a></li>

                    </ul>
                </li>



            </ul>

        </div>
    </nav>

    <div id="page-wrapper" class="gray-bg">

        <?php /*NAVIGATION TOP*/ ?>
        <div class="row border-bottom">
            <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                <div class="navbar-header">
                    <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i>
                    </a>
                </div>
                <ul class="nav navbar-top-links navbar-right">
                    <li>
                        <span class="m-r-sm text-muted welcome-message">Welcome WebApp.al</span>
                    </li>

                    <li>
                        <a href="<?php echo e(url('/logout')); ?>">
                            <i class="fa fa-sign-out"></i> Log out
                        </a>
                    </li>
                </ul>

            </nav>
        </div>
        <?php /*END NAVIGATION TOP*/ ?>


        <?php /*BODY HEADER*/ ?>
        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-12" style="padding-top: 10px;">
                <ol class="breadcrumb">
                    <li>
                        <a href="<?php echo e(url('/admin')); ?>"><?php echo e((isset($title)== true) ? $title : 'Dashboard'); ?></a>
                    </li>
                    <li class="active">
                        <strong><?php echo e((isset($subTitle)== true) ? $subTitle : 'Dashboard'); ?></strong>
                    </li>
                </ol>
            </div>
        </div>
        <?php /*BODY HEADER END*/ ?>



        <div class="wrapper wrapper-content animated fadeInRight">

            <?php /*THE CONTENT OF BODY*/ ?>
            <?php echo $__env->yieldContent('content'); ?>

        </div>

        <?php /*FOOTER*/ ?>
        <div class="footer">
            <div class="pull-right">
                Version: <b>Beta</b> | Copyright <strong>WebApp.al</strong>
            </div>
            <div>
                <strong><?php echo e(\Carbon\Carbon::now('Europe/Rome')->toDayDateTimeString()); ?></strong>
            </div>
        </div>
        <?php /*FOOTER END*/ ?>

    </div>
</div>


<!-- BEGIN CORE PLUGINS -->
<script src="<?php echo e(URL::asset('js/libs.js')); ?>" type="text/javascript"></script>
<!-- END CORE PLUGINS -->

<?php /*PUT SOME NICE SCRIPT HERE*/ ?>
<?php echo $__env->yieldContent('myScript'); ?>

</body>

</html>
