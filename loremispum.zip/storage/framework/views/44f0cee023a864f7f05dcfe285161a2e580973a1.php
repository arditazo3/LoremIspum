<div class="modal inmodal fade" id="myModalNotifyMsg" tabindex="-1" role="dialog"  aria-hidden="true">
    <div class="modal-dialog modal-lg my-very-large-modal">
        <div class="modal-content">
            <div class="modal-body">

                <div class="panel panel-<?php echo e($typeMsg); ?>">
                    <div class="panel-heading">
                        <i class="fa fa-bug"></i> Error, please contact the Administrator
                    </div>
                    <div class="panel-body" id="notificationMsg" style="overflow-y: scroll; height:500px;" >

                    </div>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>